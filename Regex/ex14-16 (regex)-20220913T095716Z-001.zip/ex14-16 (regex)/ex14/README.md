# remove leading and trailing zeros

## Task:

Create a function that takes a string input as a number and replaces leading and trailing zeros.

## Input/Output:

```
"0023.07623070"   -->   "23.0762307"  
"hello world"     -->   "hello world"  
"01230"           -->   "1230"  
```
