# check math expression

## Task:

Create a function that takes a string input and checks if it is a mathematical expression.
Supported operators: +, -, *, /, % and only integers 

## Input/Output:

```
"5 + 2"         -->    true  
"9 * 1"         -->    true  
"hello world"   -->    false  
"123"           -->    false  
"5 + foo"       -->    false  
```

---

*Addition:* You can become as complex as you like on this one, working with higly complex mathematical expression.
