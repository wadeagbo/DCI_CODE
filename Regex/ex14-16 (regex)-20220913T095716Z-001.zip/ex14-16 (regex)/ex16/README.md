# make happy

## Task
Make any face happy. Create a function that takes a sentence containing sad faces and turn them into happy ones! This involves changing only the mouths.  
Make sure to only change the face if there are eyes before them, round(3.4) wouldn't become round)3.4) (for example).


## Examples:
Sad face examples: :( 8( x( ;( 
Happy face examples: :) 8) x) ;) 

## Input / Output
```
make_happy("My current mood: :(")    -->    "My current mood: :)"  
make_happy("I was hungry 8(")        -->    "I was hungry 8)"  
make_happy("print('x(')")            -->    "print('x)')"  
